export default function Head() {
    return (
        <>
            <link
                rel="preload"
                href="/fonts/Inter.ttf"
                as="font"
                type="font/ttf"
                crossOrigin="anonymous"
            />
        </>
    )
}